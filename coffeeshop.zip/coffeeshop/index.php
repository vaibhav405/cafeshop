<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Cafe</title>
  <meta name="author" content="Alvaro Trigo Lopez" />
  <meta name="description" content="fullPage plugin by Alvaro Trigo. Pure javascript version of full screen slider." />
  <meta name="keywords" content="fullpage,jquery,alvaro,trigo,plugin,fullscren,screen,full,iphone5,apple,pure,javascript,slider,hijacking"
  />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="Resource-type" content="Document" />

  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="javascript.fullPage.css" />
  <link href="css/styles.css" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.js"></script>
  <script src="https://rawgit.com/alvarotrigo/fullPage.js/master/jquery.fullPage.js"></script>


  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Accordion - Collapse content</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>

<body>
  <header id="home">
    <nav class="navbar navbar-default navbar-fixed-top navbar navbar-inverse" data-spy="affix" data-offset-top="50">
      <div class="container-fluid">
   
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
            aria-expanded="false" style="display:none;">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">
            <img src="img/logo1.gif" alt="logo " style="width: 56px;height:56px; ">
          </a>
   
          <ul class="nav navbar-nav navbar-right">
              <li><a href="login.php">Login</a></li>
            <li><a href="index.php">Home</a></li>
            <li><a href="#section1">Aboutus</a></li>
            <li><a href="register.php">Registration</a></li>
            <li><a href="#section2">Contact us</a></li>
          
         
          </ul>
        </div>
        
    </nav>
  </header>
  <!DOCTYPE html>

</html>
  <div id="fullpage">
    <div class="section" id="section0">
      <div class="content">
				<div id="banners">
					<div class="home-2">
						<div class="banner light-opacity bganimationleft" style="background-image:url(img/banner.png); background-size:cover;">
							<div class="container-fluid home-3 ">
								<div class="banner-caption ">
									<div class="col-md-12 col-sm-12 banner-text ">
										<h1 class="col wow bounceInDown center banner-heading ">
											Behind every successful person is a substantial amount of COFFEE.
										</h1>
										<p class="banner-para ">
											Put your feet up, sit back with your favourite drink and come with us on a journey through the world of coffee.
										</p>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
    </div>
    <div class="section" id="section1">
      <!-- About us -->
      <section class="aboutus">
        <div class="container aboutCategory" style="margin-top:5%;">
          <div class="row">
            <div class="col-md-6 col-xs-12 col-sm-12">
              <img src="img/lobby-cafe.jpg" class="bg-ecom2 img-responsive" alt="aboutus-image">
            </div>
            <div class="col-md-6 col-xs-12 col-sm-12 about-desp">
              <div class="fadeInUp aboutData" style="visibility: visible;">
                <div class="headabt">About Us</div>
                <div class="spacer1"></div>
                <p class="p-txt">We are not only a place to drop in and get your morning cup of coffee (although you are more than welcome to do that), we are a place where you can sit down and enjoy that tailor-made cup of coffee.</p>
                <p class="p-txt">If you need to work, we have a seating area created specifically for you. If you need to rest, we&nbsp;have a soft-seating area in front of a stone fire place that is perfect for your weary mind and body. We offer a delicious variety of coffee from&nbsp;SafehouseCoffee made by our professionally trained baristas.</p>
                <p class="p-txt">We have everything from classic coffee to our house made specialty beverages.&nbsp; All of our sauces &amp; syrups are made in-house with all natural ingredients (no chemicals or preservatives) ensuring you the highest quality in taste &amp; health. &nbsp;You can complete your coffee with one of our delicious sweet treats made by our very own baker. We look forward to serving you at COFFEE JOURNAL</p>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile -->
 

      </section>
      <!-- About us end -->
    </div>
     <div class="section" id="section2">
      <!-- <carousel starts> -->
        <div id='carousel-custom' class='carousel slide' data-ride='carousel'>
          
          <div class="container-fluid no-padding">
            <div class='carousel-inner'>
              <div class='item active'>
                <div class="slide1">
                  <div class="row1">
                    <div class="col-md-4  col-sm-12 image1">
                      <img src='img/affogato.jpg' class='img1' />
                    </div>
                    <div class="col-md-6  col-sm-12 text">
                      <h5>AFFOGATO</h5>
                      <div class="description">
                        <p class="desc">an Italian dessert consisting of vanilla ice cream topped with a shot of espresso coffee.
                          <br>"the affogato was to die for, with the bitter espresso perfectly complementing the sweet ice cream"
                          <br>While the recipe of the affogato is more or less standard in Italy, consisting of a scoop of vanilla gelato topped with a shot of espresso, variations exist</p>
                      </div>
                    </div>
                    <div class="col-md-2  col-sm-12">
                      <div class="btncarousel">
                        <a class="btn btn-primary" href="affogato.php" target="_blank">EXPLORE HERE</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class='item'>
                <div class="slide2">
                  <div class="row1">
                    <div class="col-md-4  col-sm-12 image1">
                      <img src='img/cafe-latte.jpg' class='img1' />
                    </div>
                    <div class="col-md-6  col-sm-12 text">
                      <h5>CAFFE-LATTE</h5>
                      <div class="description">
                        <p class="desc">A latte is a coffee drink made with espresso and steamed milk. The term as used in English is a shortened form of the Italian caffè latte, caffelatte or caffellatte, which means "milk coffee"
                          <br>The term as used in English is a shortened form of the Italian caffè latte, caffelatte or caffellatte, which means "milk coffee"
                          <br> caffè latte is almost always prepared at home, for breakfast only. The coffee is brewed with a stovetop Moka pot and poured into a cup containing heated milk.</p>
                      </div>
                    </div>
                    <div class="col-md-2  col-sm-12">
                       <div class="btncarousel">
                        <a class="btn btn-primary" href="caffe-latte.php" target="_blank">EXPLORE HERE</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class='item'>
                <div class="slide3">
                  <div class="row1">
                    <div class="col-md-4  col-sm-12 image1">
                      <img src='img/Cappuccino.jpg' class='img1' />
                    </div>
                    <div class="col-md-6  col-sm-12 text">
                      <h5>CAPPUCCINO</h5>
                      <div class="description">
                        <p class="desc"> Cappuccino is a coffee drink that today is composed of double espresso and hot milk,with the surface topped with foamed milk
                          <br>The name comes from the Capuchin friars, referring to the colour of their habits,[3] and in this context referring to the colour of the beverage when milk is added in small portion to dark, brewed coffee (today mostly espre</p>
                      </div>
                    </div>
                    <div class="col-md-2  col-sm-12">
                      <div class="btncarousel">
                        <a class="btn btn-primary" href="cappuccino.php" target="_blank">EXPLORE HERE</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class='item'>
                <div class="slide4">
                  <div class="row1">
                    <div class="col-md-4  col-sm-12 image1">
                      <img src='img/double-espresso.jpg' class='img1' />
                    </div>
                    <div class="col-md-6  col-sm-12 text">
                      <h5>DOUBLE-ESPRESSO</h5>
                      <div class="description">
                        <p class="desc">Double espresso is a double shot, extracted using a double coffee filter in the portafilter
                          <br>This results in 60 ml of drink, double the amount of a single shot espresso.
                          <br>More commonly called a standard double, it is a standard in judging the espresso quality in barista competitions.</p>
                      </div>
                    </div>
                    <div class="col-md-2  col-sm-12">
                      <div class="btncarousel">
                        <a class="btn btn-primary" href="double-espresso.php" target="_blank">EXPLORE HERE</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class='item'>
                <div class="slide5">
                  <div class="row1">
                    <div class="col-md-4  col-sm-12 image1">
                      <img src='img/espresso.jpg' class='img1' />
                    </div>
                    <div class="col-md-6  col-sm-12 text">
                      <h5>ESPRESSO</h5>
                      <div class="description">
                        <p class="desc">Espresso is coffee brewed by expressing or forcing out a small amount of nearly boiling water under pressure through finely ground coffee beans.
                          <br> Espresso is generally thicker than coffee brewed by other methods, has a higher concentration of suspended and dissolved solids, and has cream on top.
                          <br>Espresso has more caffeine per unit volume than most coffee beverages</p>
                      </div>
                    </div>
                    <div class="col-md-2  col-sm-12">
                      <div class="btncarousel">
                        <a class="btn btn-primary" href="espresso.php" target="_blank">EXPLORE HERE</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
        
              <div class='item'>
                <div class="slide6">
                  <div class="row1">
                    <div class="col-md-4  col-sm-12 image1">
                      <img src='img/flat-white.jpg' class='img1' />
                    </div>
                    <div class="col-md-6  col-sm-12 text">
                      <h5>FLAT-WHITE</h5>
                      <div class="description">
                        <p class="desc"> A flat white with feather latte art,It is an espresso-based coffee drink consisting of espresso with microfoam
                          <br>It is somewhat similar to the caffè latte although smaller in volume and less microfoam
                          <br>A flat white traditionally does not incorporate latte art</p>
                      </div>
                    </div>
                    <div class="col-md-2  col-sm-12">
                      <div class="btncarousel">
                        <a class="btn btn-primary" href="flat-white.php" target="_blank">EXPLORE HERE</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class='item'>
                  <div class="slide1">
                    <div class="row1">
                      <div class="col-md-4  col-sm-12 image1">
                        <img src='img/lobby-cafe.jpg' class='img1' />
                      </div>
                      <div class="col-md-6  col-sm-12 text">
                        <h5>IRISH-COFFEE</h5>
                        <div class="description">
                          <p class="desc">Irish coffee is a cocktail consisting of hot coffee, Irish whiskey, and sugar, stirred, and topped with thick cream. 
                            <br>The coffee is drunk through the cream.
                            <br>The term "Irish coffee" is also sometimes used colloquially to refer to alcoholic coffee drinks in general.</p>
                        </div>
                      </div>
                      <div class="col-md-2  col-sm-12">
                        <div class="btncarousel">
                          <a class="btn btn-primary" href="irish-coffee.php" target="_blank">EXPLORE HERE</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class='item'>
                    <div class="slide2">
                      <div class="row1">
                        <div class="col-md-4  col-sm-12 image1">
                          <img src='img/long-black.jpg' class='img1' />
                        </div>
                        <div class="col-md-6  col-sm-12 text">
                          <h5>LONG-BLACK</h5>
                          <div class="description">
                              <p class="desc">A long black is a style of coffee, commonly found in Australia and New Zealand
                                  <br>A long black is made by pouring a double-shot of espresso or ristretto over hot water.
                                  <br>It is similar to an Americano, but with a stronger aroma and taste.</p>
                          </div>
                        </div>
                        <div class="col-md-2  col-sm-12">
                          <div class="btncarousel">
                            <a class="btn btn-primary" href="long-black.php" target="_blank">EXPLORE HERE</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class='item'>
                      <div class="slide3">
                        <div class="row1">
                          <div class="col-md-4  col-sm-12 image1">
                            <img src='img/long-macchiato.jpg' class='img1' />
                          </div>
                          <div class="col-md-6  col-sm-12 text">
                            <h5>LONG-MACCHIATO</h5>
                            <div class="description">
                                <p class="desc">A long macchiato is the same as a short macchiato but with a double shot of espresso
                                    <br>The same rule of thirds applies in the traditionally made long macchiato
                                    <br>Two shots of espresso (80mls) in a cup with a generous scoop of Vanilla ice-cream</p>
                            </div>
                          </div>
                          <div class="col-md-2  col-sm-12">
                            <div class="btncarousel">
                              <a class="btn btn-primary" href="long-macchiato.php" target="_blank">EXPLORE HERE</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class='item'>
                        <div class="slide4">
                          <div class="row1">
                            <div class="col-md-4  col-sm-12 image1">
                              <img src='img/mocha-coffee.jpg' class='img1' />
                            </div>
                            <div class="col-md-6  col-sm-12 text">
                              <h5>MOCHA-COFFEE</h5>
                              <div class="description">
                                  <p class="desc">Like a caffè latte, caffè mocha is based on espresso and hot milk
                                      <br>but with added chocolate, typically in the form of sweet cocoa powder
                                      <br>Mochas can contain dark or milk chocolate.</p>
                              </div>
                            </div>
                            <div class="col-md-2  col-sm-12">
                              <div class="btncarousel">
                                <a class="btn btn-primary" href="mocha-coffee.php" target="_blank">EXPLORE HERE</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class='item'>
                          <div class="slide5">
                            <div class="row1">
                              <div class="col-md-4  col-sm-12 image1">
                                <img src='img/piccolo-latte.jpg' class='img1' />
                              </div>
                              <div class="col-md-6  col-sm-12 text">
                                <h5>PICCOLO-LATTE</h5>
                                <div class="description">
                                    <p class="desc">a Piccolo Latte is a ristretto shot (15 – 20 ml) topped with warm,
                                        <br>silky milk served in a 100 ml glass demitasse (small latte glass) basically, a baby latte, as the Italian pronunciation suggests.</p>
                                </div>
                              </div>
                              <div class="col-md-2  col-sm-12">
                                <div class="btncarousel">
                                  <a class="btn btn-primary" href="piccolo-latte.php" target="_blank">EXPLORE HERE</a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class='item'>
                            <div class="slide6">
                              <div class="row1">
                                <div class="col-md-4  col-sm-12 image1">
                                  <img src='img/ristretto.jpg' class='img1' />
                                </div>
                                <div class="col-md-6  col-sm-12 text">
                                  <h5>RISTRETTO</h5>
                                  <div class="description">
                                      <p class="desc">Ristretto is traditionally a short shot of espresso coffee made with the normal amount of ground coffee
                                          <br>extracted with about half the amount of water in the same amount of time by using a finer grind</p>
                                  </div>
                                </div>
                                <div class="col-md-2  col-sm-12">
                                  <div class="btncarousel">
                                    <a class="btn btn-primary" href="ristretto.php" target="_blank">EXPLORE HERE</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
              <!-- Indicators -->
               <ol class='carousel-indicators hidden-xs hidden-sm'>
                <li data-target='#carousel-custom' data-slide-to='0' class='active'>
                  <img src='img/affogato.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='1'>
                  <img src='img/cafe-latte.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='2'>
                    <img src='img/Cappuccino.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='3'>
                    <img src='img/double-espresso.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='4'>
                    <img src='img/espresso.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='5'>
                    <img src='img/flat-white.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='6'>
                    <img src='img/lobby-cafe.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='7'>
                    <img src='img/long-black.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='8'>
                    <img src='img/long-macchiato.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='9'>
                    <img src='img/mocha-coffee.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='10'>
                    <img src='img/piccolo-latte.jpg' alt='' />
                </li>
                <li data-target='#carousel-custom' data-slide-to='11'>
                    <img src='img/ristretto.jpg' alt='' />
                </li>
              </ol>
        
            </div>
        
            <a class='left carousel-control' href='#carousel-custom' data-slide='prev'>
              <span class='glyphicon glyphicon-chevron-left'></span>
            </a>
            <a class='right carousel-control' href='#carousel-custom' data-slide='next'>
              <span class='glyphicon glyphicon-chevron-right'></span>
            </a>
        
          </div>
        
        
        
        </div>
      <!-- <carousel ends> -->
          <div id="footer-container">
              <footer id="footer" class="custom-footer  m-none">
                <div class="container wow animated fadeInUp">
                  <div class="row">
                    <div class="col-md-2">
      
                      <a href="#" class="text-decoration-none">
                        <div class="header-logo">
                          <img _ngcontent-c1="" alt="cafe" src="img/cafe-cafe.png">
                        </div>
      
                      </a>
                    </div>
      
                    <div class="col-md-3 ">
      
                      <div class="contact-info">
                        <h7 class="text-color-white font-weight-bold mb-xs">Contact Information</h7>
                        <div class="info">
                          <i class="material-icons">email</i>
                          <a href="mailto:info@cafe.in"> info@Cafe.in</a>
                          <br>
                        </div>
                        <div class="info">
                          <i class="material-icons">call</i>
                          <span style="
                    color: white;">+91-12332122, 555566667, 1212889967 </span>
                        </div>
      
      
      
                        <div id="social">
                          <a class="facebookBtn smGlobalBtn" href="https://www.facebook.com"></a>
                          <a class="twitterBtn smGlobalBtn" href="https://twitter.com"></a>
                          <a class="googleplusBtn smGlobalBtn" href="https://plus.google.com"></a>
                          <a class="linkedinBtn smGlobalBtn" href="https://www.linkedin.com"></a>
                          <a class="youtubeBtn smGlobalBtn" href="https://www.youtube.com"></a>
                          <a class="tumblrBtn smGlobalBtn" href="https://www.instagram.com"></a>
                        </div>
                      </div>
                    </div>
      
                    <div class="col-md-7 ">
                      <div class="row">
      
                        <div class="col-md-4 ">
      
                          <h7 class="text-color-white">Quick Links</h7>
                          <ul>
                            <li>
                              <a class="custom-text-color-1" href="" title="Career">
                                Careers
                              </a>
                            </li>
                            <li>
                              <a class="custom-text-color-1" href="" title="Blog">
                                Blog
                              </a>
                            </li>
                          </ul>
      
                        </div>
                        <div class="col-md-4">
                          <ul class="col2">
                            <li class="foot1">
                              <a class="custom-text-color-1" href="" title="Contact Us">
                                Contact Us
                              </a>
                            </li>
                            <li class="foot">
                              <a class="custom-text-color-1" href="" title="Home">
                                Home
                              </a>
                            </li>
      
                          </ul>
                        </div>
                      </div>
      
                    </div>
      
      
      
      
                  </div>
      
      
      
                  <div class="container">
                    <div class="bottom-border-top m-none pt-md pb-md">
                      <div class="row">
                        <div class="col-md-12 center pt-md">
                          <div class="bottom" style="
                  color: white"> © Copyright 2016-2018 CAFE CAFE.
                            <a href="https://www.cafe.com/" target="_blank"></a>
                          </div>
      
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
    </div>
 

  </div>

  <script type="text/javascript" src="javascript.fullPage.js"></script>
  <script type="text/javascript">
    fullpage.initialize('#fullpage', {
      anchors: ['firstPage', 'secondPage','lastpage'],
      menu: '#menu',
      scrollingSpeed: 700,
      autoScrolling: true,
      fitToSection: true,
      fitToSectionDelay: 1000,
      scrollBar: false,
      scrollOverflow: true,
      css3: true
    });

  </script>

</body>

</html>