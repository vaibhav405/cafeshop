<?php   
 session_start();  
 $connect = mysqli_connect("localhost", "root", "", "cafe");  
 if(isset($_POST["add_to_cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array($_GET["id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"],  
                     'item_name'               =>     $_POST["hidden_name"],  
                     'item_price'          =>     $_POST["hidden_price"],  
                     'item_quantity'          =>     $_POST["quantity"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
           }  
           else  
           {  
                echo '<script>alert("Item Already Added")</script>';  
                echo '<script>window.location="flat-white.php"</script>';  
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     $_GET["id"],  
                'item_name'               =>     $_POST["hidden_name"],  
                'item_price'          =>     $_POST["hidden_price"],  
                'item_quantity'          =>     $_POST["quantity"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  
 }  
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>';  
                     echo '<script>window.location="flat-white.php"</script>';  
                }  
           }  
      }  
 }  
 ?>  


<link href="css/coffee.css" rel="stylesheet">
<head>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Cafe</title>
  <meta name="author" content="Alvaro Trigo Lopez" />
  <meta name="description" content="fullPage plugin by Alvaro Trigo. Pure javascript version of full screen slider." />
  <meta name="keywords" content="fullpage,jquery,alvaro,trigo,plugin,fullscren,screen,full,iphone5,apple,pure,javascript,slider,hijacking"
  />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="Resource-type" content="Document" />

  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="javascript.fullPage.css" />
  <link href="css/styles.css" rel="stylesheet">
  <link href="css/rtr.css" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.js"></script>
  <script src="https://rawgit.com/alvarotrigo/fullPage.js/master/jquery.fullPage.js"></script>


  <!-- rtr -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
      <link href="style.css" type="text/css" rel="stylesheet" />
</head>
  <header id="home">
    <nav class="navbar navbar-default navbar-fixed-top navbar navbar-inverse" data-spy="affix" data-offset-top="50">
      <div class="container-fluid">
   
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
            aria-expanded="false" style="display:none;">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button> 
          <a class="navbar-brand" href="#">
            <img src="img/logo1.gif" alt="logo " style="width: 56px;height:56px; ">
          </a>
   
          <ul class="nav navbar-nav navbar-right">
        <li style="margin: 9px;
color: whitesmoke;">Hi,<?php echo($_SESSION['username']);?></li>
              <li><a href="logout.php">Logout</a></li>
            <li><a href="#home">Home</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="menu.php">Menus</a></li>
            <li><a href="#contact">Contact us</a></li>
          
         
          </ul>
        </div>
        
    </nav>
  </header>
  <div style="clear:both"></div>  
    <br />  <br />  <br />  
    <h3>Order Details</h3>  
    <div class="table-responsive">  
         <table class="table table-bordered">  
              <tr>  
                   <th width="40%">Item Name</th>  
                   <th width="10%">Quantity</th>  
                   <th width="20%">Price</th>  
                   <th width="15%">Total</th>  
                   <th width="5%">Action</th>  
              </tr>  
              <?php   
              if(!empty($_SESSION["shopping_cart"]))  
              {  
                   $total = 0;  
                   foreach($_SESSION["shopping_cart"] as $keys => $values)  
                   {  
              ?>  
              <tr>  
                <td><?php echo "FLAT-WHITE" ?></td>  
                <td><?php echo $values["item_quantity"]; ?></td>  
                <td>RS&nbsp;<?php echo "700" ?></td>  
                <td>RS&nbsp;<?php echo number_format($values["item_quantity"] * 700, 2); ?></td>  
                <td><a href="flat-white.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>  
           </tr> 
              <?php  
                        $total = $total + ($values["item_quantity"] * 700);  
                   }  
              ?>  
              <tr>  
                   <td colspan="3" align="right">Total</td>  
                   <td align="right">RS&nbsp; <?php echo number_format($total, 2); ?></td>  
                   <td></td>  
              </tr>  
              <?php  
              }  
              ?>  
         </table>  
    </div> 
<main class="container">
    <!-- Left Column / Headphones Image -->
    <div class="left-column">
      <img data-image="red" class="active" src="img/flat-white.jpg" alt="">
    </div>
   
   
    <!-- Right Column -->
    <div class="right-column">
      <?php  
      $query = "SELECT * FROM tblproduct LIMIT 1";  
     
      $result = mysqli_query($connect, $query);  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
      ?>  
      <!-- Product Description -->
      <div class="product-description">
        
        <h1>FLAT-WHITE</h1>
        <p>
          A flat white with feather latte art,It is an espresso-based coffee drink consisting of espresso with microfoam.It is somewhat similar to the caffè latte although smaller in volume and less microfoam</p>
      </div>
   
      <!-- Product Configuration -->
      <div class="product-configuration">
        <!-- Cable Configuration -->
        <div class="cable-config">
            <form method="post" action="flat-white.php?action=add&id=<?php echo $row["id"]; ?>">  
              <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">  
                   <img src="img/flat-white.jpg" class="img-responsive" /><br />  
                   <h4 class="text-info"><?php echo "FLAT-WHITE" ?></h4>  
                   <h4 class="text-danger"><?php echo "RS 700" ?></h4>  
                   <input type="text" name="quantity" class="form-control" value="1" />  
                   <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />  
                   <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />  
                   <h3>Ratings</h3>  
                   <fieldset class="rating">
                    <input type="radio" id="star5" name="rating" value="5" />
                    <label class = "full" for="star5" title="Awesome - 5 stars"></label>
                    <input type="radio" id="star4half" name="rating" value="4 and a half" />
                    <label class="half" for="star4half" title="Pretty good - 4.5 stars"></label>
                    <input type="radio" id="star4" name="rating" value="4" />
                    <label class = "full" for="star4" title="Pretty good - 4 stars"></label>
                    <input type="radio" id="star3half" name="rating" value="3 and a half" />
                    <label class="half" for="star3half" title="Meh - 3.5 stars"></label>
                    <input type="radio" id="star3" name="rating" value="3" /><label class = "full" for="star3" title="Meh - 3 stars"></label>
                    <input type="radio" id="star2half" name="rating" value="2 and a half" />
                    <label class="half" for="star2half" title="Kinda bad - 2.5 stars"></label>
                    <input type="radio" id="star2" name="rating" value="2" /><label class = "full" for="star2" title="Kinda bad - 2 stars"></label>
                    <input type="radio" id="star1half" name="rating" value="1 and a half" />
                    <label class="half" for="star1half" title="Meh - 1.5 stars"></label>
                    <input type="radio" id="star1" name="rating" value="1" />
                    <label class = "full" for="star1" title="Sucks big time - 1 star"></label>
                    <input type="radio" id="starhalf" name="rating" value="half" />
                    <label class="half" for="starhalf" title="Sucks big time - 0.5 stars"></label>
                </fieldset>
                   <input type="submit" name="add_to_cart" style="margin-top:-10px;" class="btn btn-success" value="Add to Cart" />  
              </div> 
               
         </form>  
         
         <?php  
        }  
   }  
   ?>  
   
</div>  

        </div>
      </div>
      
      </div>
    </div>
  </main>

