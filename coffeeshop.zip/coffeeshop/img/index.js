{
  "_args": [
    [
      "glob-parent@3.1.0",
      "D:\\myrsav3p1"
    ]
  ],
  "_development": true,
  "_from": "glob-parent@^3.1.0",
  "_id": "glob-parent@3.1.0",
  "_inBundle": false,
  "_integrity": "sha1-nmr2KZ2NO9K9QEMIMr0RPfkGxa4=",
  "_location": "/webpack-dev-server/glob-parent",
  "_phantomChildren": {
    "is-extglob": "2.1.1"
  },
  "_requested": {
    "type": "range",
    "registry": true,
    "raw": "glob-parent@^3.1.0",
    "name": "glob-parent",
    "escapedName": "glob-parent",
    "rawSpec": "^3.1.0",
    "saveSpec": null,
    "fetchSpec": "^3.1.0"
  },
  "_requiredBy": [
    "/webpack-dev-server/chokidar"
  ],
  "_resolved": "https://registry.npmjs.org/glob-parent/-/glob-parent-3.1.0.tgz",
  "_shasum": "9e6af6299d8d3bd2bd40430832bd113df906c5ae",
  "_spec": "glob-parent@^3.1.0",
  "_where": "D:\\myrsav3p1\\node_modules\\webpack-dev-server\\node_modules\\chokidar",
  "author": {
    "name": "Elan Shanker",
    "url": "https://github.com/es128"
  },
  "bugs": {
    "url": "https://github.com/es128/glo